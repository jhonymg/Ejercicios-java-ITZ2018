/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traductormorse;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * @author Jhony Maldonado
 */
public class TraductorMorse {

    private static Hashtable<String, String> morse = getDataMorse();
    private static Hashtable<String, String> alfanumerico = getDataAlfanumerico();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int op;
        do {
            try {
                System.out.println("---------Menu--------");
                System.out.println("1.-Traducir texto a morse");
                System.out.println("2.-Traducir morse a texto");
                System.out.println("3.-Ver alfabeto");
                System.out.println("4.-Salir \n");
                op = Integer.parseInt(sc.nextLine());
                String texto = "";
                String[] palabras, caracteres;
                switch (op) {
                    case 1:
                        System.out.println("Escribe el texto que deseas traducir (solo se aceptan numeros y letras cualquier otro caracter no se traducira) ");
                        texto = sc.nextLine();
                        palabras = texto.toUpperCase().trim().split(" ");
                        String salida = "";
                        for (String palabra : palabras) {
                            caracteres = palabra.trim().split("");
                            for (String caracter : caracteres) {
                                String traductor = morse.get(caracter);
                                if (traductor != null) {
                                    salida += traductor + " ";
                                }
                            }
                            salida = salida.trim();
                            salida += "   ";
                        }
                        System.out.println("Tu entrada en morse es : " + salida);
                        break;
                    case 2:
                        System.out.println("Escribe el texto en morse que deseas traducir \nUsa un espacio para separa por letra y tres por palabra ");
                        System.out.println("Cualquier caracter en morse no reconocido no sera traducido");
                        System.out.println("Escribir dos espacios entre letras sera tomado como 1 y poner mas de tres sera tomado como separacion de palabras");
                        texto = sc.nextLine();
                        palabras = texto.trim().split("   ");
                        salida = "";
                        for (String palabra : palabras) {
                            caracteres = palabra.trim().split(" ");
                            for (String caracter : caracteres) {
                                if (caracter.equals(" ")) {
                                    System.out.println("Es espacio");
                                }
                                String traductor = alfanumerico.get(caracter);
                                if (traductor != null) {
                                    salida += traductor;
                                }
                            }
                            salida = salida.trim();
                            salida += " ";
                        }
                        System.out.println("Tu entrada en texto es : " + salida);
                        break;

                    case 3:
                        int cont=2;
                        Enumeration claves=morse.keys();
                        Object clave,valor;
                        String cadena="";
                        ArrayList listaO=new ArrayList();
                        
                        while (claves.hasMoreElements()) {
                           clave = claves.nextElement();
                           listaO.add(clave);
                        }
                        Collections.sort(listaO);
                        for (Object claveO : listaO) {
                            valor=morse.get(claveO);
                           cadena+=claveO+" = "+valor+"   ";
                           if(cont==4){
                               cadena+="\n";
                               cont=1;
                           }
                           cont++;
                        }
                        System.out.println(cadena);
                        break;
                    case 4:
                        System.out.println("Adios!!!");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                        break;
                }
            } catch (Exception e) {
                op = 0;
                System.out.println("Opcion no valida ");
            }
        } while (op != 4);
    }

    private static Hashtable<String, String> getDataMorse() {
        Hashtable<String, String> morse = new Hashtable<>();
        morse.put("A", ".-");
        morse.put("B", "-...");
        morse.put("C", "-.-.");
        morse.put("D", "-..");
        morse.put("E", ".");
        morse.put("F", "..-.");
        morse.put("G", "--.");
        morse.put("H", "....");
        morse.put("I", "..");
        morse.put("J", ".---");
        morse.put("K", "-.-");
        morse.put("L", ".-..");
        morse.put("M", "--");
        morse.put("N", "-.");
        morse.put("O", "---");
        morse.put("P", ".--.");
        morse.put("Q", "--.-");
        morse.put("R", ".-.");
        morse.put("S", "...");
        morse.put("T", "-");
        morse.put("U", "..-");
        morse.put("V", "...-");
        morse.put("W", ".--");
        morse.put("X", "-..-");
        morse.put("Y", "-.--");
        morse.put("Z", "--..");
        morse.put("1", ".----");
        morse.put("2", "..---");
        morse.put("3", "...--");
        morse.put("4", "....-");
        morse.put("5", ".....");
        morse.put("6", "-....");
        morse.put("7", "--...");
        morse.put("8", "---..");
        morse.put("9", "----.");
        morse.put("0", "-----");
        return morse;
    }

    private static Hashtable<String, String> getDataAlfanumerico() {
        Hashtable<String, String> alfanumerico = new Hashtable<>();
        alfanumerico.put(".-", "A");
        alfanumerico.put("-...", "B");
        alfanumerico.put("-.-.", "C");
        alfanumerico.put("-..", "D");
        alfanumerico.put(".", "E");
        alfanumerico.put("..-.", "F");
        alfanumerico.put("--.", "G");
        alfanumerico.put("....", "H");
        alfanumerico.put("..", "I");
        alfanumerico.put(".---", "J");
        alfanumerico.put("-.-", "K");
        alfanumerico.put(".-..", "L");
        alfanumerico.put("--", "M");
        alfanumerico.put("-.", "N");
        alfanumerico.put("---", "O");
        alfanumerico.put(".--.", "P");
        alfanumerico.put("--.-", "Q");
        alfanumerico.put(".-.", "R");
        alfanumerico.put("...", "S");
        alfanumerico.put("-", "T");
        alfanumerico.put("..-", "U");
        alfanumerico.put("...-", "V");
        alfanumerico.put(".--", "W");
        alfanumerico.put("-..-", "X");
        alfanumerico.put("-.--", "Y");
        alfanumerico.put("--..", "Z");
        alfanumerico.put(".----", "1");
        alfanumerico.put("..---", "2");
        alfanumerico.put("...--", "3");
        alfanumerico.put("....-", "4");
        alfanumerico.put(".....", "5");
        alfanumerico.put("-....", "6");
        alfanumerico.put("--...", "7");
        alfanumerico.put("---..", "8");
        alfanumerico.put("----.", "9");
        alfanumerico.put("-----", "0");
        return alfanumerico;
    }
}
