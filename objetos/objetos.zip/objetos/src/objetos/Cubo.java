/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

/**
 *
 * @author Jhony Maldonado
 */
public class Cubo extends Cuadrado{
    
    public Cubo(float lado) {
        super(lado);
    }

    @Override
    public float calcularPerimetro() {
        return lado*12; //To change body of generated methods, choose Tools | Templates.
    }
    public float calcularVolumen(){
        return lado*lado*lado;
    }
    
}
