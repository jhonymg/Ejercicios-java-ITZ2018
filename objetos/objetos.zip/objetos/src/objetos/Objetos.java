/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

import java.util.Scanner;

/**
 *
 * @author Jhony Maldonado
 */
public class Objetos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        String op = "", entrada = "";
        while (!op.equals("s")) {
            System.out.println("Ingresa el tamaño de el lado ó escribe s para salir : ");
            entrada = sc.next();
            if (entrada.toLowerCase().equals("s")) {
                op = "s";
            } else {
                try {
                    float lado = Float.parseFloat(entrada);
                    int opC;
                    do {
                        System.out.println("El valor actual del lado es : " + lado);
                        System.out.println("¿Que deseas hacer ?");
                        System.out.println("1.-Calcular el area de un cuadrado");
                        System.out.println("2.-Calcular el perimetro de un cuadrado");
                        System.out.println("3.-Calcular el volumen de un cubo");
                        System.out.println("4.-Calcular el perimetro de un cubo");
                        System.out.println("5.-Cancelar");
                        opC = sc.nextInt();
                        Cuadrado cuadrado;
                        Cubo cubo;
                        switch (opC) {
                            case 1:
                                cuadrado = new Cuadrado(lado);
                                System.out.println("El area del cuadrado es : " + cuadrado.calcularArea());
                                break;
                            case 2:
                                cuadrado = new Cuadrado(lado);
                                System.out.println("El perimetro del cuadrado es : " + cuadrado.calcularPerimetro());
                                break;
                            case 3:
                                cubo = new Cubo(lado);
                                System.out.println("El volumen del cubo es : " + cubo.calcularVolumen());
                                break;
                            case 4:
                                cubo = new Cubo(lado);
                                System.out.println("El perimetro del cubo es : " + cubo.calcularPerimetro());
                                break;
                        }
                        System.out.println("----------------------------------");
                    } while (opC != 5);
                } catch (Exception e) {
                    System.out.println("Lo que digitaste no es un numero ");
                }
            }

        }
    }

}
