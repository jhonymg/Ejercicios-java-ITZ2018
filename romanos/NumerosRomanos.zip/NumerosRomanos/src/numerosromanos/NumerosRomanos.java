/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numerosromanos;

import java.util.Scanner;

/**
 *
 * @author Jhony Maldonado
 */
public class NumerosRomanos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        String op = "y";
        while (!op.equals("n")) {
            System.out.println("Digita un numero entre 1 y 1000 para convertirlo a romano");
            int num = 0;
            try {
                num = Integer.parseInt(sc.nextLine());
                if (num < 1 || num > 1000) {
                    System.out.println("El numero no esta en el rango");
                } else {
                    convertir(num);
                }
                System.out.println("Deseas continuar? y/n");
                op = sc.nextLine();
            } catch (Exception e) {
                System.out.println("ESto no es un numero");
            }
        }
    }

    private static void convertir(int num) {
        String salida = "";
         String[] numeros;
        if (num == 1000) {
            System.out.println("M");
        } else {
            String numS=Integer.toString(num);
           
            switch(numS.length()){
                case 1:
                    salida+=getUnidades(num);
                    break;
                case 2:
                    numeros=numS.split("");
                    salida+=getDecenas(Integer.parseInt(numeros[0]));
                    salida+=getUnidades(Integer.parseInt(numeros[1]));
                    break;
                case 3:
                    numeros=numS.split("");
                    salida+=getCentenas(Integer.parseInt(numeros[0]));
                    salida+=getDecenas(Integer.parseInt(numeros[1]));
                    salida+=getUnidades(Integer.parseInt(numeros[2]));
                    break;
            }
            System.out.println(salida);
        }
    }

    private static String getUnidades(int num) {
        String salida = "";
        switch (num) {
            case 1:
                salida = "I";
                break;
            case 2:
                salida = "II";
                break;
            case 3:
                salida = "III";
                break;
            case 4:
                salida = "IV";
                break;
            case 5:
                salida = "V";
                break;
            case 6:
                salida = "VI";
                break;
            case 7:
                salida = "VII";
                break;
            case 8:
                salida = "VIII";
                break;
            case 9:
                salida = "IX";
                break;
        }
        return salida;
    }

    private static String getDecenas(int num) {
        String salida = "";
        switch (num) {
            case 1:
                salida = "X";
                break;
            case 2:
                salida = "XX";
                break;
            case 3:
                salida = "XXX";
                break;
            case 4:
                salida = "XL";
                break;
            case 5:
                salida = "L";
                break;
            case 6:
                salida = "LX";
                break;
            case 7:
                salida = "LXX";
                break;
            case 8:
                salida = "LXXX";
                break;
            case 9:
                salida = "XC";
                break;
        }
        return salida;
    }
        private static String getCentenas(int num) {
        String salida="";
        switch (num) {
            case 1:
                salida="C";
            break;
            case 2:
                salida="CC";
            break;
            case 3:
                salida="CCC";
            break;
            case 4:
                salida="CD";
            break;
            case 5:
                salida="D";
            break;
            case 6:
                salida="DC";
            break;
            case 7:
                salida="DCC";
            break;
            case 8:
                salida="DCCC";
            break;
            case 9:
                salida="CM";
            break;
        }
        return salida;
    }
}
